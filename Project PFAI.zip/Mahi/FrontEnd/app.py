from flask import Flask, render_template, request, jsonify, session
import secrets
import re

app = Flask(__name__)
app.secret_key = secrets.token_hex(16)

events = {
    "BTS World Tour": {
        "date": "15 April 2026",
        "venue": "Seoul Olympic Stadium",
        "tickets": 300,
        "price": 120,
        "image": "🎤"
    },
    "Jungkook Golden Live": {
        "date": "20 May 2026",
        "venue": "Tokyo Dome, Japan",
        "tickets": 250,
        "price": 110,
        "image": "🎸"
    },
    "Blackpink Born Pink Tour": {
        "date": "3 March 2026",
        "venue": "Los Angeles Arena",
        "tickets": 180,
        "price": 150,
        "image": "💖"
    },
    "IU Love Poem Concert": {
        "date": "12 June 2026",
        "venue": "Busan Concert Hall",
        "tickets": 140,
        "price": 90,
        "image": "🎵"
    },
    "Taylor Swift Eras Tour": {
        "date": "10 July 2026",
        "venue": "London Wembley Stadium",
        "tickets": 500,
        "price": 250,
        "image": "✨"
    },
    "The Weeknd After Hours Tour": {
        "date": "25 August 2026",
        "venue": "New York Madison Square Garden",
        "tickets": 350,
        "price": 180,
        "image": "🌙"
    },
    "Atif Aslam Live": {
        "date": "14 February 2026",
        "venue": "Lahore Expo Center",
        "tickets": 200,
        "price": 50,
        "image": "🎤"
    },
    "Arijit Singh Soul Tour": {
        "date": "18 March 2026",
        "venue": "Dubai Coca-Cola Arena",
        "tickets": 220,
        "price": 95,
        "image": "🎶"
    },
    "Coldplay Music of the Spheres Tour": {
        "date": "1 September 2026",
        "venue": "Berlin Olympic Stadium",
        "tickets": 450,
        "price": 210,
        "image": "🌍"
    },
    "Ed Sheeran Divide Tour": {
        "date": "5 October 2026",
        "venue": "Sydney ANZ Stadium",
        "tickets": 300,
        "price": 160,
        "image": "🎸"
    },
    "Billie Eilish Happier Than Ever Tour": {
        "date": "30 November 2026",
        "venue": "Toronto Scotiabank Arena",
        "tickets": 260,
        "price": 140,
        "image": "💚"
    },
    "Imagine Dragons Mercury Tour": {
        "date": "22 December 2026",
        "venue": "Singapore Indoor Stadium",
        "tickets": 280,
        "price": 130,
        "image": "🐉"
    },
    "Enhypen Fate Tour": {
        "date": "8 February 2026",
        "venue": "Bangkok Impact Arena",
        "tickets": 210,
        "price": 80,
        "image": "⭐"
    },
    "NCT Dream Dream Show": {
        "date": "27 February 2026",
        "venue": "Tokyo Ariake Arena",
        "tickets": 230,
        "price": 85,
        "image": "💚"
    },
    "Aespa Synk Tour": {
        "date": "14 April 2026",
        "venue": "Jakarta Indoor Stadium",
        "tickets": 190,
        "price": 100,
        "image": "🔮"
    },
    "Lisa Solo Live": {
        "date": "21 April 2026",
        "venue": "Bangkok National Stadium",
        "tickets": 350,
        "price": 160,
        "image": "👑"
    },
    "Zayn Malik Asia Tour": {
        "date": "10 May 2026",
        "venue": "Dubai World Trade Center",
        "tickets": 300,
        "price": 140,
        "image": "🎤"
    },
    "Diljit Dosanjh Born to Shine": {
        "date": "25 May 2026",
        "venue": "Delhi Indira Gandhi Stadium",
        "tickets": 270,
        "price": 70,
        "image": "🌟"
    },
    "Ali Zafar Live": {
        "date": "17 June 2026",
        "venue": "Karachi Arts Council",
        "tickets": 180,
        "price": 40,
        "image": "🎵"
    },
    "Fujii Kaze Love All Tour": {
        "date": "3 July 2026",
        "venue": "Kyoto Hall",
        "tickets": 200,
        "price": 95,
        "image": "🎹"
    },
    "Jay Chou Carnival Tour": {
        "date": "19 August 2026",
        "venue": "Beijing National Stadium",
        "tickets": 380,
        "price": 170,
        "image": "🎪"
    },
    "Jackson Wang Magic Man Tour": {
        "date": "14 October 2026",
        "venue": "Hong Kong AsiaWorld Arena",
        "tickets": 240,
        "price": 125,
        "image": "✨"
    },
    "Jolin Tsai Ugly Beauty Tour": {
        "date": "29 December 2026",
        "venue": "Taipei Arena",
        "tickets": 310,
        "price": 150,
        "image": "💄"
    }
}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/chat', methods=['POST'])
def chat():
    data = request.json
    user_message = data.get('message', '').strip().lower()
    
    # Initialize booking state in session if not exists
    if 'booking_state' not in session:
        session['booking_state'] = {'step': 0, 'event': '', 'name': '', 'quantity': 0}
    
    booking_state = session['booking_state']
    
    # Greetings
    if re.search(r'\b(hi|hello|hey|salam)\b', user_message):
        response = {
            'message': "Hello! 🎉 Welcome to EventHub Ticketing Assistant. I can help you:\n\n• View all upcoming concerts\n• Check ticket availability\n• Book tickets\n\nHow can I assist you today?",
            'type': 'text'
        }
        return jsonify(response)
    
    # How are you
    if re.search(r'how are you', user_message):
        response = {
            'message': "I'm doing great! 😊 Ready to help you book amazing concerts and events. What would you like to do?",
            'type': 'text'
        }
        return jsonify(response)
    
    # Bot name
    if re.search(r'(your name|who are you)', user_message):
        response = {
            'message': "I'm EventHub – your Event & Concert Ticketing Chatbot! 🎫 I'm here to help you discover and book tickets for amazing concerts worldwide.",
            'type': 'text'
        }
        return jsonify(response)
    
    # List all events
    if re.search(r'\b(events|concerts|shows|upcoming|list|all)\b', user_message):
        response = {
            'message': "Here are all our upcoming concerts! 🎵",
            'type': 'events',
            'events': events
        }
        return jsonify(response)
    
    # Check tickets for specific event
    if re.search(r'tickets for', user_message):
        event_name = user_message.split('tickets for')[-1].strip().title()
        
        # Find matching event (case insensitive)
        matched_event = None
        for event in events.keys():
            if event_name.lower() in event.lower():
                matched_event = event
                break
        
        if matched_event:
            event_info = events[matched_event]
            response = {
                'message': f"📊 **{matched_event}**\n\n✅ Available Tickets: {event_info['tickets']}\n💵 Price per Ticket: ${event_info['price']}\n📍 Venue: {event_info['venue']}\n📅 Date: {event_info['date']}\n\nWould you like to book tickets?",
                'type': 'text'
            }
        else:
            response = {
                'message': f"Sorry, I couldn't find an event matching '{event_name}'. Please check the event name and try again, or type 'show events' to see all available concerts.",
                'type': 'text'
            }
        return jsonify(response)
    
    # Start booking process
    if re.search(r'\b(book|reserve|buy|purchase|i want)\b', user_message) and booking_state['step'] == 0:
        booking_state['step'] = 1
        session['booking_state'] = booking_state
        response = {
            'message': "Great! Let's book your tickets! 🎫\n\nPlease tell me the concert name you'd like to attend. Type 'show events' if you want to see all available concerts.",
            'type': 'text'
        }
        return jsonify(response)
    
    # Booking Step 1: Get event name
    if booking_state['step'] == 1:
        # Find matching event
        matched_event = None
        for event in events.keys():
            if user_message.lower() in event.lower() or event.lower() in user_message.lower():
                matched_event = event
                break
        
        if matched_event:
            booking_state['event'] = matched_event
            booking_state['step'] = 2
            session['booking_state'] = booking_state
            response = {
                'message': f"Perfect! You've selected **{matched_event}** 🎵\n\n💵 Price: ${events[matched_event]['price']} per ticket\n📍 {events[matched_event]['venue']}\n📅 {events[matched_event]['date']}\n\nHow many tickets would you like to book?",
                'type': 'text'
            }
        else:
            response = {
                'message': "I couldn't find that event. Please enter a valid concert name or type 'show events' to see all available concerts.",
                'type': 'text'
            }
        return jsonify(response)
    
    # Booking Step 2: Get quantity
    if booking_state['step'] == 2:
        try:
            quantity = int(re.search(r'\d+', user_message).group())
            event = booking_state['event']
            
            if quantity <= 0:
                response = {
                    'message': "Please enter a valid number of tickets (greater than 0).",
                    'type': 'text'
                }
            elif quantity > events[event]['tickets']:
                response = {
                    'message': f"Sorry! Only {events[event]['tickets']} tickets are available for {event}. Please enter a smaller number.",
                    'type': 'text'
                }
            else:
                booking_state['quantity'] = quantity
                booking_state['step'] = 3
                session['booking_state'] = booking_state
                total = quantity * events[event]['price']
                response = {
                    'message': f"Excellent! {quantity} ticket(s) for ${events[event]['price']} each = **${total}** total 💰\n\nPlease enter your full name to confirm the booking:",
                    'type': 'text'
                }
        except:
            response = {
                'message': "Please enter a valid number of tickets (e.g., 1, 2, 3).",
                'type': 'text'
            }
        return jsonify(response)
    
    # Booking Step 3: Get name and confirm
    if booking_state['step'] == 3:
        name = user_message.title()
        event = booking_state['event']
        quantity = booking_state['quantity']
        
        # Process booking
        events[event]['tickets'] -= quantity
        total_cost = quantity * events[event]['price']
        
        # Reset booking state
        session['booking_state'] = {'step': 0, 'event': '', 'name': '', 'quantity': 0}
        
        response = {
            'message': f"✅ **BOOKING CONFIRMED!** ✅\n\n👤 Name: {name}\n🎵 Concert: {event}\n🎫 Tickets: {quantity}\n💵 Price per Ticket: ${events[event]['price']}\n💰 Total Cost: ${total_cost}\n📍 Venue: {events[event]['venue']}\n📅 Date: {events[event]['date']}\n\n🎉 **Your tickets have been reserved!** 🎉\n\n🌐 Please visit the official website to complete your purchase and payment.\n\n🔗 Go to: www.eventhub-tickets.com/checkout\n\nYour reservation code: EH{quantity}{name[:3].upper()}{event[:3].upper()}\n\nWould you like to book more tickets?",
            'type': 'text'
        }
        return jsonify(response)
    
    # Thank you
    if re.search(r'\b(thank|thanks)\b', user_message):
        response = {
            'message': "You're welcome! 💜 Is there anything else I can help you with? Feel free to ask about events or book more tickets!",
            'type': 'text'
        }
        return jsonify(response)
    
    # Goodbye
    if re.search(r'\b(bye|goodbye|allah hafiz)\b', user_message):
        response = {
            'message': "Goodbye! 🎵 Have a music-filled day! Come back anytime to book more amazing concerts! 🎉",
            'type': 'text'
        }
        return jsonify(response)
    
    # Default response
    response = {
        'message': "I'm not sure I understood that. I can help you with:\n\n• View all events (type 'show events')\n• Check tickets (type 'tickets for [event name]')\n• Book tickets (type 'book tickets')\n\nWhat would you like to do?",
        'type': 'text'
    }
    return jsonify(response)

if __name__ == '__main__':
    app.run(debug=True)