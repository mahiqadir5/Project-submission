// Get elements
const chatMessages = document.getElementById('chatMessages');
const chatForm = document.getElementById('chatForm');
const userInput = document.getElementById('userInput');

// Handle form submission
chatForm.addEventListener('submit', function(e) {
    e.preventDefault();
    const message = userInput.value.trim();
    
    if (message) {
        sendMessage(message);
        userInput.value = '';
    }
});

// Send message function
async function sendMessage(message) {
    // Add user message to chat
    addUserMessage(message);
    
    // Show typing indicator
    showTypingIndicator();
    
    try {
        // Send message to backend
        const response = await fetch('/api/chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ message: message })
        });
        
        const data = await response.json();
        
        // Remove typing indicator
        removeTypingIndicator();
        
        // Add bot response
        if (data.type === 'events') {
            addEventsMessage(data.message, data.events);
        } else {
            addBotMessage(data.message);
        }
        
    } catch (error) {
        console.error('Error:', error);
        removeTypingIndicator();
        addBotMessage("Sorry, I'm having trouble connecting. Please try again.");
    }
}

// Add user message to chat
function addUserMessage(message) {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message user-message';
    
    messageDiv.innerHTML = `
        <div class="message-content">
            <div class="message-bubble">${escapeHtml(message)}</div>
            <small class="message-time">${getCurrentTime()}</small>
        </div>
        <div class="message-avatar">
            <i class="fas fa-user"></i>
        </div>
    `;
    
    chatMessages.appendChild(messageDiv);
    scrollToBottom();
}

// Add bot message to chat
function addBotMessage(message) {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message bot-message';
    
    // Format message (support for markdown-like formatting)
    const formattedMessage = formatMessage(message);
    
    messageDiv.innerHTML = `
        <div class="message-avatar">
            <i class="fas fa-robot"></i>
        </div>
        <div class="message-content">
            <div class="message-bubble">${formattedMessage}</div>
            <small class="message-time">${getCurrentTime()}</small>
        </div>
    `;
    
    chatMessages.appendChild(messageDiv);
    scrollToBottom();
}

// Add events message with event cards
function addEventsMessage(message, events) {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message bot-message';
    
    let eventsHtml = '<div class="events-grid">';
    
    for (const [name, details] of Object.entries(events)) {
        const availabilityClass = details.tickets < 50 ? 'text-danger' : 'text-success';
        const availabilityText = details.tickets === 0 ? 'Sold Out' : 
                                 details.tickets < 50 ? `Only ${details.tickets} left!` : 
                                 `${details.tickets} available`;
        
        eventsHtml += `
            <div class="event-card-chat">
                <div class="event-icon">${details.image}</div>
                <div class="event-name">${name}</div>
                <div class="event-info">
                    <i class="fas fa-calendar"></i> ${details.date}
                </div>
                <div class="event-info">
                    <i class="fas fa-map-marker-alt"></i> ${details.venue}
                </div>
                <div class="event-info">
                    <i class="fas fa-tag"></i> $${details.price} per ticket
                </div>
                <div class="event-info ${availabilityClass}">
                    <i class="fas fa-ticket-alt"></i> ${availabilityText}
                </div>
            </div>
        `;
    }
    
    eventsHtml += '</div>';
    
    messageDiv.innerHTML = `
        <div class="message-avatar">
            <i class="fas fa-robot"></i>
        </div>
        <div class="message-content" style="max-width: 90%;">
            <div class="message-bubble">
                ${escapeHtml(message)}
                ${eventsHtml}
            </div>
            <small class="message-time">${getCurrentTime()}</small>
        </div>
    `;
    
    chatMessages.appendChild(messageDiv);
    scrollToBottom();
}

// Show typing indicator
function showTypingIndicator() {
    const typingDiv = document.createElement('div');
    typingDiv.className = 'message bot-message';
    typingDiv.id = 'typingIndicator';
    
    typingDiv.innerHTML = `
        <div class="message-avatar">
            <i class="fas fa-robot"></i>
        </div>
        <div class="message-content">
            <div class="typing-indicator">
                <div class="typing-dot"></div>
                <div class="typing-dot"></div>
                <div class="typing-dot"></div>
            </div>
        </div>
    `;
    
    chatMessages.appendChild(typingDiv);
    scrollToBottom();
}

// Remove typing indicator
function removeTypingIndicator() {
    const typingIndicator = document.getElementById('typingIndicator');
    if (typingIndicator) {
        typingIndicator.remove();
    }
}

// Quick message buttons
function sendQuickMessage(message) {
    sendMessage(message);
}

// Format message (convert **text** to bold, etc.)
function formatMessage(message) {
    let formatted = escapeHtml(message);
    
    // Bold text: **text** or __text__
    formatted = formatted.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    formatted = formatted.replace(/__(.*?)__/g, '<strong>$1</strong>');
    
    // Line breaks
    formatted = formatted.replace(/\n/g, '<br>');
    
    return formatted;
}

// Escape HTML to prevent XSS
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Get current time
function getCurrentTime() {
    const now = new Date();
    return now.toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit' 
    });
}

// Scroll to bottom of chat
function scrollToBottom() {
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

// Clear chat
function clearChat() {
    if (confirm('Are you sure you want to clear the chat history?')) {
        // Keep only the welcome message
        const welcomeMessage = chatMessages.querySelector('.message.bot-message');
        chatMessages.innerHTML = '';
        if (welcomeMessage) {
            chatMessages.appendChild(welcomeMessage);
        }
    }
}

// Auto-resize input on Enter key
userInput.addEventListener('keypress', function(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        chatForm.dispatchEvent(new Event('submit'));
    }
});

// Focus input on page load
window.addEventListener('load', function() {
    userInput.focus();
});

// Add some helpful suggestions when user starts typing
let typingTimeout;
userInput.addEventListener('input', function() {
    clearTimeout(typingTimeout);
    
    typingTimeout = setTimeout(() => {
        const value = this.value.toLowerCase();
        
        // You can add autocomplete suggestions here if needed
        if (value.length > 2) {
            // Show suggestions
        }
    }, 500);
});

// Add animation when page loads
window.addEventListener('load', function() {
    const messages = document.querySelectorAll('.message');
    messages.forEach((msg, index) => {
        msg.style.opacity = '0';
        msg.style.transform = 'translateY(20px)';
        
        setTimeout(() => {
            msg.style.transition = 'all 0.5s ease';
            msg.style.opacity = '1';
            msg.style.transform = 'translateY(0)';
        }, index * 100);
    });
});

// Emoji button (you can add emoji picker library if needed)
document.querySelector('.chat-input-area .btn-icon').addEventListener('click', function() {
    // Add emoji picker functionality here
    const emojis = ['😊', '🎉', '🎵', '🎤', '🎸', '❤️', '👍', '🔥'];
    const randomEmoji = emojis[Math.floor(Math.random() * emojis.length)];
    userInput.value += randomEmoji;
    userInput.focus();
});