import nltk
from nltk.chat.util import Chat, reflections

events = {
    "BTS World Tour": {
        "date": "15 April 2026",
        "venue": "Seoul Olympic Stadium",
        "tickets": 300,
        "price": 120
    },
    "Jungkook Golden Live": {
        "date": "20 May 2026",
        "venue": "Tokyo Dome, Japan",
        "tickets": 250,
        "price": 110
    },
    "Blackpink Born Pink Tour": {
        "date": "3 March 2026",
        "venue": "Los Angeles Arena",
        "tickets": 180,
        "price": 150
    },
    "IU Love Poem Concert": {
        "date": "12 June 2026",
        "venue": "Busan Concert Hall",
        "tickets": 140,
        "price": 90
    },
    "Taylor Swift Eras Tour": {
        "date": "10 July 2026",
        "venue": "London Wembley Stadium",
        "tickets": 500,
        "price": 250
    },
    "The Weeknd After Hours Tour": {
        "date": "25 August 2026",
        "venue": "New York Madison Square Garden",
        "tickets": 350,
        "price": 180
    },
    "Atif Aslam Live": {
        "date": "14 February 2026",
        "venue": "Lahore Expo Center",
        "tickets": 200,
        "price": 50
    },
    "Arijit Singh Soul Tour": {
        "date": "18 March 2026",
        "venue": "Dubai Coca-Cola Arena",
        "tickets": 220,
        "price": 95
    },
    "Coldplay Music of the Spheres Tour": {
        "date": "1 September 2026",
        "venue": "Berlin Olympic Stadium",
        "tickets": 450,
        "price": 210
    },
    "Ed Sheeran Divide Tour": {
        "date": "5 October 2026",
        "venue": "Sydney ANZ Stadium",
        "tickets": 300,
        "price": 160
    },
    "Billie Eilish Happier Than Ever Tour": {
        "date": "30 November 2026",
        "venue": "Toronto Scotiabank Arena",
        "tickets": 260,
        "price": 140
    },
    "Imagine Dragons Mercury Tour": {
        "date": "22 December 2026",
        "venue": "Singapore Indoor Stadium",
        "tickets": 280,
        "price": 130
    },
    "Enhypen Fate Tour": {
        "date": "8 February 2026",
        "venue": "Bangkok Impact Arena",
        "tickets": 210,
        "price": 80
    },
    "NCT Dream Dream Show": {
        "date": "27 February 2026",
        "venue": "Tokyo Ariake Arena",
        "tickets": 230,
        "price": 85
    },
    "Aespa Synk Tour": {
        "date": "14 April 2026",
        "venue": "Jakarta Indoor Stadium",
        "tickets": 190,
        "price": 100
    },
    "Lisa Solo Live": {
        "date": "21 April 2026",
        "venue": "Bangkok National Stadium",
        "tickets": 350,
        "price": 160
    },
    "Zayn Malik Asia Tour": {
        "date": "10 May 2026",
        "venue": "Dubai World Trade Center",
        "tickets": 300,
        "price": 140
    },
    "Diljit Dosanjh Born to Shine": {
        "date": "25 May 2026",
        "venue": "Delhi Indira Gandhi Stadium",
        "tickets": 270,
        "price": 70
    },
    "Ali Zafar Live": {
        "date": "17 June 2026",
        "venue": "Karachi Arts Council",
        "tickets": 180,
        "price": 40
    },
    "Fujii Kaze Love All Tour": {
        "date": "3 July 2026",
        "venue": "Kyoto Hall",
        "tickets": 200,
        "price": 95
    },
    "Jay Chou Carnival Tour": {
        "date": "19 August 2026",
        "venue": "Beijing National Stadium",
        "tickets": 380,
        "price": 170
    },
    "Jackson Wang Magic Man Tour": {
        "date": "14 October 2026",
        "venue": "Hong Kong AsiaWorld Arena",
        "tickets": 240,
        "price": 125
    },
    "Jolin Tsai Ugly Beauty Tour": {
        "date": "29 December 2026",
        "venue": "Taipei Arena",
        "tickets": 310,
        "price": 150
    }
}


pairs = [
    [r"(?i).*(hi|hello|hey).*",
     ["Hello!  Welcome to EventHub Ticketing Assistant. How can I help you today?"]],

    [r"(?i).*(how are you).*",
     ["I'm doing great!  Ready to help you book concerts and events."]],

    [r"(?i).*(your name|who are you).*",
     ["I'm EventHub – your Event & Concert Ticketing Chatbot!"]],

    # List events
    [r"(?i).*(events|concerts|shows|upcoming).*",
     ["Here are the upcoming concerts:\n\n" +
      "\n".join([f"- {name} on {info['date']} at {info['venue']} (Price: ${info['price']})"
                 for name, info in events.items()]) +
      "\n\nWhich event would you like details for or want to book?"]],

    # Ticket availability
    [r"(?i).*tickets for (.*)",
     ["Checking ticket availability…"]],

    [r"(?i).*(remaining tickets|available tickets|tickets left).*",
     ["Sure! Please tell me the concert name."]],

    # Booking start
    [r"(?i).*(book|reserve|ticket|i want to go|buy).*",
     ["Great!  Which concert do you want to book?"]],

    [r"(?i).*(thank you|thanks).*",
     ["You're welcome! Need help with another booking?"]],

    [r"(?i).*(bye|allah hafiz|goodbye).*",
     ["Goodbye!  Have a music-filled day!"]]
]

chatbot = Chat(pairs, reflections)


def chatbot_app():
    print("EventHub Assistant: Welcome to EventHub Ticketing! (Type 'exit' to quit)")
    
    booking_mode = False
    step = 0
    booking = {
        "event": "",
        "name": "",
        "tickets": 0
    }

    while True:
        user = input("You: ")

        if user.lower() in ["exit", "quit"]:
            print("EventHub Assistant: Goodbye! 🎤")
            break

        # show ticket count
        if user.lower().startswith("tickets for"):
            event_name = user[11:].strip()
            if event_name in events:
                print(f"EventHub Assistant: {event_name} has {events[event_name]['tickets']} tickets left. Price per ticket: ${events[event_name]['price']}")
            else:
                print("EventHub Assistant: Sorry, this event doesn't exist.")
            continue

        # start booking
        if any(word in user.lower() for word in ["book", "ticket", "reserve", "buy"]):
            print("EventHub Assistant: Great! Please enter the concert name:")
            booking_mode = True
            step = 1
            continue

        if booking_mode:
            if step == 1:
                if user in events:
                    booking["event"] = user
                    print(f"EventHub Assistant: Ticket price is ${events[user]['price']}. How many tickets do you want?")
                    step = 2
                else:
                    print("EventHub Assistant: Please enter a valid concert name.")
                continue

            elif step == 2:
                try:
                    qty = int(user)
                    if qty <= events[booking["event"]]["tickets"]:
                        booking["tickets"] = qty
                        print("EventHub Assistant: Please enter your name:")
                        step = 3
                    else:
                        print("EventHub Assistant: Not enough tickets left. Try fewer.")
                except:
                    print("EventHub Assistant: Please enter a number.")
                continue

            elif step == 3:
                booking["name"] = user
                
                # calculate total
                total_cost = booking["tickets"] * events[booking["event"]]["price"]

                # reduce ticket count
                events[booking["event"]]["tickets"] -= booking["tickets"]

                print("\n BOOKING CONFIRMED ")
                print("------------------------------------")
                print(f"Concert: {booking['event']}")
                print(f"Name: {booking['name']}")
                print(f"Tickets: {booking['tickets']}")
                print(f"Price per Ticket: ${events[booking['event']]['price']}")
                print(f"Total Cost: ${total_cost}")
                print(f"Venue: {events[booking['event']]['venue']}")
                print(f"Date: {events[booking['event']]['date']}")
                print("------------------------------------")
                print("Enjoy the show!")

                booking_mode = False
                step = 0
                continue
        
        response = chatbot.respond(user)
        if response:
            print("EventHub Assistant:", response)
        else:
            print("EventHub Assistant: Sorry, I didn't understand. Try saying it differently.")

chatbot_app()
